// --- خانه امتیاز ---
let students = JSON.parse(localStorage.getItem("students") || "{}");
let rewards = JSON.parse(localStorage.getItem("rewards") || "[]");
let currentStudent = localStorage.getItem("currentStudent") || "";

function saveData() {
  localStorage.setItem("students", JSON.stringify(students));
  localStorage.setItem("rewards", JSON.stringify(rewards));
  localStorage.setItem("currentStudent", currentStudent);
}

function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2200);
}

// --- ناوبری اپ ---
function showView(name) {
  if (name !== "login" && !currentStudent) name = "login";
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  const el = document.getElementById("view-" + name);
  if (el) el.classList.add("active");
  document.querySelectorAll(".nav-btn").forEach(b =>
    b.classList.toggle("active", b.dataset.view === name));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function login() {
  const name = document.getElementById("studentName").value.trim();
  if (!name) { toast("لطفاً اسم خودت را وارد کن."); return; }
  if (!students[name]) students[name] = { score: 0, history: [] };
  currentStudent = name;
  saveData();
  render();
  showView("home");
  toast("خوش آمدی " + name + " 👋");
}

function logout() {
  currentStudent = "";
  saveData();
  render();
  showView("login");
}

// امتیاز: بدون حد پایین — می‌تواند تا هر عدد منفی برود
function changePoints(type) {
  if (!currentStudent) return;
  const inputId = type === 1 ? "addPointsInput" : "subPointsInput";
  const value = parseInt(document.getElementById(inputId).value);
  if (isNaN(value) || value <= 0) { toast("یک عدد معتبر وارد کن."); return; }

  students[currentStudent].score += type * value; // هیچ کف یا محدودیتی وجود ندارد

  students[currentStudent].history.unshift({
    text: type === 1 ? `افزودن ${value} امتیاز` : `کسر ${value} امتیاز`,
    date: new Date().toLocaleString("fa-IR")
  });
  if (students[currentStudent].history.length > 50) students[currentStudent].history.pop();

  document.getElementById(inputId).value = "";
  saveData();
  render();
  toast(type === 1 ? `+${value} امتیاز اضافه شد ✅` : `${value} امتیاز کم شد`);
}

function addReward() {
  const name = document.getElementById("rewardName").value.trim();
  const cost = parseInt(document.getElementById("rewardCost").value);
  if (!name || isNaN(cost) || cost <= 0) { toast("نام جایزه و امتیاز معتبر وارد کن."); return; }
  rewards.push({ name, cost });
  document.getElementById("rewardName").value = "";
  document.getElementById("rewardCost").value = "";
  saveData();
  render();
  toast("جایزه ثبت شد 🎁");
}

function buyReward(index) {
  const reward = rewards[index];
  const student = students[currentStudent];
  if (student.score < reward.cost) { toast("امتیاز تو برای این جایزه کافی نیست."); return; }
  student.score -= reward.cost; // کسر کامل مجاز است؛ بدون حد پایین
  student.history.unshift({
    text: `انتخاب جایزه: ${reward.name} (-${reward.cost})`,
    date: new Date().toLocaleString("fa-IR")
  });
  saveData();
  render();
  toast("جایزه با موفقیت انتخاب شد 🎉");
}

function render() {
  document.getElementById("view-login").classList.toggle("hidden", !!currentStudent);
  const dash = ["home", "score", "rewards"];
  if (!currentStudent) showView("login");

  if (currentStudent) {
    document.getElementById("currentName").textContent = currentStudent;
    const s = students[currentStudent].score;
    const el = document.getElementById("currentScore");
    el.textContent = s;
    el.classList.toggle("negative", s < 0);

    const historyDiv = document.getElementById("history");
    historyDiv.innerHTML = students[currentStudent].history.length
      ? students[currentStudent].history.map(item => `
          <div class="item-box">
            <div><strong>${item.text}</strong><br><span class="small">${item.date}</span></div>
          </div>`).join("")
      : "<p class='empty'>هنوز هیچ فعالیتی ثبت نشده.</p>";
  }

  const rewardsList = document.getElementById("rewardsList");
  rewardsList.innerHTML = rewards.length === 0
    ? "<p class='empty'>هنوز جایزه‌ای ثبت نشده.</p>"
    : rewards.map((reward, index) => {
        const ok = currentStudent && students[currentStudent].score >= reward.cost;
        return `
        <div class="item-box">
          <div><strong>${reward.name}</strong><br><span class="small">هزینه: ${reward.cost} امتیاز</span></div>
          <button class="btn btn-sm ${ok ? 'btn-orange' : 'btn-ghost'}" onclick="buyReward(${index})"
            ${currentStudent ? "" : "disabled"}>انتخاب</button>
        </div>`;
      }).join("");
}

function resetAll() {
  if (!confirm("همه اطلاعات پاک شود؟")) return;
  localStorage.clear();
  students = {}; rewards = []; currentStudent = "";
  render();
  showView("login");
  toast("همه اطلاعات پاک شد.");
}

render();
if (currentStudent) showView("home");
